import boto3
from datetime import datetime, timezone

ec2 = boto3.client('ec2')
MAX_HOURS = 2

def lambda_handler(event, context):
    response = ec2.describe_instances(
        Filters=[{'Name': 'instance-state-name', 'Values': ['running']}]
    )

    stop_list = []

    for r in response['Reservations']:
        for i in r['Instances']:
            launch_time = i['LaunchTime']
            running_hours = (datetime.now(timezone.utc) - launch_time).total_seconds() / 3600

            if running_hours >= MAX_HOURS:
                stop_list.append(i['InstanceId'])

    if stop_list:
        ec2.stop_instances(InstanceIds=stop_list)

    return {"Stopped": stop_list}

