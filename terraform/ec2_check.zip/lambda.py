import boto3
import os

ec2 = boto3.client('ec2')
sns = boto3.client('sns')

INSTANCE_ID = os.environ['INSTANCE_ID']
SNS_ARN = os.environ['SNS_ARN']

def lambda_handler(event, context):
    res = ec2.describe_instances(InstanceIds=[INSTANCE_ID])
    state = res['Reservations'][0]['Instances'][0]['State']['Name']

    if state == "running":
        sns.publish(
            TopicArn=SNS_ARN,
            Subject="EC2 Hourly Running Alert",
            Message=f"EC2 Instance {INSTANCE_ID} is RUNNING"
        )
